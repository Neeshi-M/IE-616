import numpy as np 
import matplotlib.pyplot as plt 
def f(g,p): 
return ((100-g)(g+p)+(g-2)(0.5*g+0.5-p)+g)/99 
def k(g,p): 
return f(g,p)-f(2,p) 
def s(p): 
count=0 
for gin range(2,101): 
count+=k(g,p) 
return -count 
def c(p): 
return (s(p)-s(0))/(s(100)-s(0)) 
final=[] 
new_final=[] 
for i in range(0,101): 
new_final.append(c(i)) 
g_arr = [] 
for gl in range(2,101): 
reward_arr = [] 
for j in range(100): 
g2 = np.random.randint(2,101) 
if gl > g2: 
reward= g2 - i 
elif gl < g2: 
reward= gl + i 
else: 
reward= gl 
reward_arr.append(reward) 
g_arr.append(sum(reward_arr)/100) 
count1=0 
for j in range(0,99): 
countl+=g_arr[0]-g_arr[j] 
final.append(countl) 
# print(final) 
final2=[] 
for i in range(101): 
final2.append((final[i]-final[0])/(final[100]-final[0])) 
plt.plot(range(0,101), final2, color='darkblue', label='Simulation results', linewidth='3') 
plt.plot(range(0,101), new_final, color='orange', label='Mathematical results', linewidth='l.5',
linestyle='--') 
plt.xlabel("p", fontsize='16') 
travelers_ dilemma( strength ).py 
plt.ylabel("Strength of nash equilibrium", fontsize='16') 
plt.title("Traveller's dilemma (Strength vs p)", fontsize='20', fontweight='bold') 
plt.legend() 
manager= plt.get_current_fig_manager() 
manager.full_screen_toggle() 
plt.subplots_adjust(left=0.062, right=0.629, bottom=0.398, top=0.932, wspace=0.2, hspace=0.2) 
plt.show()
