import numpy as np 
import matplotlib.pyplot as plt 
from matplotlib.animation import FuncAnimation 
import time 
def f(xl, x2): 
if xl != x2: 
return (xl+x2)/2 
return 50 
def g(xl, x2): 
return 100 - f(xl, x2) 
def move(a, b): 
if a< b: 
p_a = f(a, b) 
if f(a+l, b) > p_a: 
return 1 
elif f(a-1, b) > p_a: 
return -1 
else: 
return 0 
if a> b: 
p_a = g(a, b) 
if g(a+l, b) > p_a: 
return 1 
elif g(a-1, b) > p_a: 
return -1 
else: 
return 0 
if a== b: 
p_a = f(a, b) 
if g(a+l, b) > p_a: 
return 1 
elif f(a-1, b) > p_a: 
return -1 
return 0 
# Parameters 
L = 101 # Length of line 
n_iter = 100 # Number of iterations 
# Generate initial points 
xl = np.random.randint(0, 100) 
x2 = np.random.randint(0, 100) 
# Create figure and axis objects 
fig, ax= plt.subplots() 
img = plt.imread('beach.jpeg') 
# Set the background image
ax.imshow(img,extent= [0, L, 0, 1], aspect= 'auto ') 
# Set axis limits and labels 
ax.set_xlim([0, 100]) 
ax.set_ylim([0, 1]) 
# Create empty scatter plot objects 
pl, = ax.plot([],[], 'bo') 
p2, = ax .plot ([], [], 'ro') 
# Load images to be used for points 
imgl = plt.imread('tom2.jpeg') 
img2 = plt.imread('jerry.png') 
# Define update function for animation 
def update(i): 
global xl,x2 
ax.clear() 
hotelling.py 
ax.imshow(img,extent= [0, L, 0, 1], aspect= 'auto ') 
ax.set_yticks([]) 
ax.set_xlim([0, 100]) 
ax.set_ylim([0, 1]) 
# Create empty scatter plot objects 
pl, = ax.plot([],[], 'bo') 
time.sleep(0.1) 
p2, = ax .plot ([], [], 'ro') 
imgl = plt.imread('tom2.jpeg') 
img2 = plt.imread('jerry.png') 
if i %2 == 0: 
xl += move(xl, x2) 
ax.imshow(imgl, extent= [xl-10, x1+10, 0.25, 0.55], aspect= 'auto ') 
ax.imshow(img2, extent= [x2-8, x2+8, 0.3, 0.5], aspect= 'auto ') 
else: 
x2 += move(x2, xl) 
ax.imshow(img2, extent= [x2-8, x2+8, 0.3, 0.5], aspect= 'auto ') 
ax.imshow(imgl, extent= [xl-10, x1+10, 0.25, 0.55], aspect= 'auto ') 
ax.set_xlabel('Position', fontsize=16) 
plt.title("Hotelling's law (Nash Equillibrium)", fontsize=20, fontweight= 'bold ') 
pl.set_data(xl, 0.4) 
p2.set_data(x2, 0.4) 
if(i >= 120):
ani_xl.event_source.stop() 
return pl,p2 
# Create animation object 
ani_xl = FuncAnimation(fig, update, frames= range(2*n_iter), interval= 50)
# Display animation 
manager= plt.get_current_fig_manager() 
manager.full_screen_toggle() 
 
plt.subplots_adjust(left=0.056, right=0.616, bottom=0.416, top=0.922, wspace=0.2, hspace=0.2) 
plt.show()
